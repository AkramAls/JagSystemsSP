﻿Public Class frmAddEmployee
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()  'close this form
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If String.IsNullOrEmpty(txtFirstName.Text) Then
            MessageBox.Show("Please enter first name.")
            txtFirstName.Focus()
            Return
        End If
        If String.IsNullOrEmpty(txtLastName.Text) Then
            MessageBox.Show("Please enter last name.")
            txtLastName.Focus()
            Return
        End If
        If String.IsNullOrEmpty(txtEmail.Text) Then
            MessageBox.Show("Please enter email.")
            txtEmail.Focus()
            Return
        End If
        If String.IsNullOrEmpty(txtPassword.Text) Then
            MessageBox.Show("Please enter password.")
            txtPassword.Focus()
            Return
        End If
        If String.IsNullOrEmpty(txtConfirmPass.Text) Then
            MessageBox.Show("Please enter confirm password.")
            txtConfirmPass.Focus()
            Return
        End If

        If Not txtPassword.Text.Equals(txtConfirmPass.Text) Then
            MessageBox.Show("Password and confirm password did not matched!")
            txtConfirmPass.Clear()
            txtPassword.Clear()
            txtPassword.Focus()
            Return
        End If

        Try
            Dim adapter As New WorkloadTrackingSystemDBDataSetTableAdapters.EmployeesTableAdapter
            Dim result As Integer = adapter.AddEmployee(txtFirstName.Text, txtLastName.Text, chBxIsManager.Checked, txtEmail.Text, txtPassword.Text)

            If result > 0 Then
                MessageBox.Show("Employee added successfully.")
            Else
                MessageBox.Show("Employee add fail.")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        ClearFields()
    End Sub

    Private Sub frmAddEmployee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ClearFields()
    End Sub

    Private Sub ClearFields()
        txtFirstName.Clear()
        txtLastName.Clear()
        txtEmail.Clear()
        txtPassword.Clear()
        txtConfirmPass.Clear()
        chBxIsManager.Checked = False

        txtFirstName.Focus()
    End Sub
End Class