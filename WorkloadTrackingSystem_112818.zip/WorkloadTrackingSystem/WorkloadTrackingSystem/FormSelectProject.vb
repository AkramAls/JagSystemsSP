﻿Public Class frmSelectProject
    Private Sub frmSelectProject_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'WorkloadTrackingSystemDBDataSet.Projects' table. You can move, or remove it, as needed.
        Me.ProjectsTableAdapter.Fill(Me.WorkloadTrackingSystemDBDataSet.Projects)
        'get login employee id
        Dim loginFrm As frmLogin = Me.Owner
        lblEmpId.Text = "Employee ID: " & loginFrm.DeveloperId.ToString
    End Sub

    Private Sub btnProjectInfo_Click(sender As Object, e As EventArgs) Handles btnProjectInfo.Click
        Dim objFrmProjectInfo As New frmProjectInfo()
        Dim loginFrm As frmLogin = Me.Owner
        objFrmProjectInfo.ShowDialog(loginFrm)
    End Sub

    Private Sub btnEnterHours_Click(sender As Object, e As EventArgs) Handles btnEnterHours.Click
        Dim objFrmEnterHrs As New frmEnterHrs()
        Dim loginFrm As frmLogin = Me.Owner
        objFrmEnterHrs.ShowDialog(loginFrm)
    End Sub

    Private Function ValidateInputs() As Boolean
        If cmBxProjects.SelectedIndex < 0 Then
            MessageBox.Show("Please select a project.")
            Return False
        End If
        If cmBxTasks.SelectedIndex < 0 Then
            MessageBox.Show("Please select a task.")
            Return False
        End If

        If Not IsNumeric(txtTargetHrs.Text) Then
            MessageBox.Show("Please enter valid targeted task hours.")
            Return False
        End If

        Return True
    End Function

    Private Sub btnAssignTask_Click(sender As Object, e As EventArgs) Handles btnAssignTask.Click
        Try
            If ValidateInputs() Then
                'get selected project id
                Dim projectId As Integer = CInt(cmBxProjects.SelectedValue)
                'get target hours
                Dim targetHrs As Decimal = CDec(txtTargetHrs.Text)
                'get login employee id
                Dim loginFrm As frmLogin = Me.Owner
                Dim empId As Integer = loginFrm.DeveloperId
                Dim taskName As String = cmBxTasks.Text

                Dim taskAdapter As New WorkloadTrackingSystemDBDataSetTableAdapters.TasksTableAdapter
                Dim result As Integer = taskAdapter.AddTask(projectId, empId, taskName, 0,
                                                            targetHrs, "Not Started", dtpTargetEndDate.Value)

                If result > 0 Then
                    MessageBox.Show("Task assigned successfully.")
                Else
                    MessageBox.Show("Could not assigned the task.")
                End If
                ClearInputs()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ClearInputs()
        cmBxProjects.SelectedIndex = -1
        cmBxTasks.SelectedIndex = -1
        txtTargetHrs.Clear()
        dtpTargetEndDate.Value = Today
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        ClearInputs()
    End Sub
End Class