﻿Public Class frmManagerPanel
    Private Sub btnCreateProject_Click(sender As Object, e As EventArgs) Handles btnCreateProject.Click
        Dim objFrmCreateProj As New frmCreateProject
        objFrmCreateProj.ShowDialog()
    End Sub

    Private Sub btnAddEmployee_Click(sender As Object, e As EventArgs) Handles btnAddEmployee.Click
        Dim objFrmAddEmp As New frmAddEmployee
        objFrmAddEmp.ShowDialog()
    End Sub

    Private Sub btnSelectProject_Click(sender As Object, e As EventArgs) Handles btnSelectProject.Click

    End Sub

    Private Sub frmManagerPanel_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class