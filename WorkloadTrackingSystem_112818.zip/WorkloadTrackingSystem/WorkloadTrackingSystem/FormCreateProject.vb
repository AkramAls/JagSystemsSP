﻿Public Class frmCreateProject
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            If ValidateInputs() Then
                Dim adapter As New WorkloadTrackingSystemDBDataSetTableAdapters.ProjectsTableAdapter
                Dim result As Integer = adapter.AddProject(txtProjectName.Text, txtProjectDescription.Text, "Not Started", dtpStartDate.Value, dtpEndDate.Value, CDec(txtBudgetedHrs.Text))

                If result > 0 Then
                    MessageBox.Show("Project added successfully.")
                Else
                    MessageBox.Show("Project add fail.")
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        ClearFields()
    End Sub
    Private Function ValidateInputs() As Boolean
        If String.IsNullOrEmpty(txtProjectName.Text) Then
            MessageBox.Show("Please enter project name.")
            txtProjectName.Focus()
            Return False
        End If

        If String.IsNullOrEmpty(txtProjectDescription.Text) Then
            MessageBox.Show("Please enter project description.")
            txtProjectDescription.Focus()
            Return False
        End If
        If cmBxProjectStatus.SelectedIndex < 0 Then
            MessageBox.Show("Please select project status.")
            Return False
        End If
        If String.IsNullOrEmpty(dtpStartDate.Value.ToString) Then
            MessageBox.Show("Please select project start date.")
            dtpStartDate.Focus()
            Return False
        End If
        If String.IsNullOrEmpty(dtpEndDate.Value.ToString) Then
            MessageBox.Show("Please select projected end date.")
            dtpEndDate.Focus()
            Return False
        End If
        If Not IsNumeric(txtBudgetedHrs.Text) Then
            MessageBox.Show("Budgeted hours must be a numeric value.")
            txtBudgetedHrs.Clear()
            txtBudgetedHrs.Focus()
            Return False
        End If
        If CDec(txtBudgetedHrs.Text) < 1 Then
            MessageBox.Show("Budgeted hours must be greater than zero.")
            txtBudgetedHrs.Clear()
            txtBudgetedHrs.Focus()
            Return False
        End If

        Return True
    End Function
    Private Sub ClearFields()
        txtProjectName.Clear()
        txtProjectDescription.Clear()
        dtpStartDate.Value = Today
        txtBudgetedHrs.Clear()
        dtpEndDate.Value = Today.AddMonths(1)

        txtProjectName.Focus()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        ClearFields()
        Me.Close()
    End Sub

    Private Sub frmCreateProject_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmBxProjectStatus.SelectedIndex = 0
    End Sub
End Class