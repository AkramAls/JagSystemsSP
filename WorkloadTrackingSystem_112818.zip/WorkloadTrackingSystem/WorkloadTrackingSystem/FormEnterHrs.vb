﻿Public Class frmEnterHrs
    Dim loginFrm As frmLogin
    Dim assignTaskAdapter = New WorkloadTrackingSystemDBDataSetTableAdapters.AssignedTasksTableAdapter
    Dim taskAdapter = New WorkloadTrackingSystemDBDataSetTableAdapters.TasksTableAdapter
    Dim taskHrsAdapter = New WorkloadTrackingSystemDBDataSetTableAdapters.TaskHoursTableAdapter

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        dtpDate.Value = Today
        txtHours.Clear()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            If dgvTasks.SelectedRows.Count > 0 Then
                Dim hrsWorked As Decimal
                If Not IsNumeric(txtHours.Text) Then
                    MessageBox.Show("Hours worked must be a numeric value.")
                    txtHours.SelectAll()
                    Return
                Else
                    hrsWorked = CDec(txtHours.Text)
                End If

                Dim taskId As Integer = CInt(dgvTasks.SelectedRows(0).Cells(0).Value)
                Dim actualHrs As Decimal = CDec(dgvTasks.SelectedRows(0).Cells(2).Value)
                Dim assignHrs As Decimal = CDec(dgvTasks.SelectedRows(0).Cells(3).Value)
                Dim status As String = dgvTasks.SelectedRows(0).Cells(4).Value.ToString


                If taskHrsAdapter.AddTaskHours(taskId, dtpDate.Value, hrsWorked) > 0 Then
                    MessageBox.Show("Hours worked has saved successfully.")

                    'now update tasks table
                    'update status and start date
                    If status.Equals("Not Started") Then
                        taskAdapter.UpdateStatus("In Progress", taskId)
                        taskAdapter.UpdateStartDate(dtpDate.Value, taskId)
                    End If
                    'update actual hours
                    taskAdapter.UpdateActualHours((hrsWorked + actualHrs), taskId)

                    dgvTasks.DataSource = Nothing
                    dgvTasks.DataSource = assignTaskAdapter.GetData(loginFrm.DeveloperId)

                    dtpDate.Value = Today
                    txtHours.Clear()
                Else
                    MessageBox.Show("Hours worked has not saved successfully.")
                End If

            Else
                MessageBox.Show("Please select a Task to add hours worked.")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub frmEnterHrs_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            'get login employee id
            loginFrm = Me.Owner
            lblEmpId.Text = "Employee ID: " & loginFrm.DeveloperId.ToString

            dgvTasks.DataSource = assignTaskAdapter.GetData(loginFrm.DeveloperId)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class