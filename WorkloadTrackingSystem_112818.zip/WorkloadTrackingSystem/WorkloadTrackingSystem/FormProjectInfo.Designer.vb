﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmProjectInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.dgvProjectInfo = New System.Windows.Forms.DataGridView()
        Me.lblEmpId = New System.Windows.Forms.Label()
        CType(Me.dgvProjectInfo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvProjectInfo
        '
        Me.dgvProjectInfo.AllowUserToAddRows = False
        Me.dgvProjectInfo.AllowUserToDeleteRows = False
        Me.dgvProjectInfo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvProjectInfo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvProjectInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvProjectInfo.Location = New System.Drawing.Point(18, 69)
        Me.dgvProjectInfo.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.dgvProjectInfo.Name = "dgvProjectInfo"
        Me.dgvProjectInfo.ReadOnly = True
        Me.dgvProjectInfo.RowHeadersVisible = False
        Me.dgvProjectInfo.Size = New System.Drawing.Size(1290, 622)
        Me.dgvProjectInfo.TabIndex = 0
        '
        'lblEmpId
        '
        Me.lblEmpId.AutoSize = True
        Me.lblEmpId.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmpId.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblEmpId.Location = New System.Drawing.Point(18, 14)
        Me.lblEmpId.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblEmpId.Name = "lblEmpId"
        Me.lblEmpId.Size = New System.Drawing.Size(141, 25)
        Me.lblEmpId.TabIndex = 9
        Me.lblEmpId.Text = "Employee ID:"
        '
        'frmProjectInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1326, 709)
        Me.Controls.Add(Me.lblEmpId)
        Me.Controls.Add(Me.dgvProjectInfo)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmProjectInfo"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Project Information"
        CType(Me.dgvProjectInfo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvProjectInfo As DataGridView
    Friend WithEvents lblEmpId As Label
End Class
