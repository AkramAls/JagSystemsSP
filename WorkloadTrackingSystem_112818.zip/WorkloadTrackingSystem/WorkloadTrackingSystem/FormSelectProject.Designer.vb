﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSelectProject
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmBxTasks = New System.Windows.Forms.ComboBox()
        Me.btnEnterHours = New System.Windows.Forms.Button()
        Me.btnProjectInfo = New System.Windows.Forms.Button()
        Me.cmBxProjects = New System.Windows.Forms.ComboBox()
        Me.ProjectsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.WorkloadTrackingSystemDBDataSet = New WorkloadTrackingSystem.WorkloadTrackingSystemDBDataSet()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ProjectsTableAdapter = New WorkloadTrackingSystem.WorkloadTrackingSystemDBDataSetTableAdapters.ProjectsTableAdapter()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtTargetHrs = New System.Windows.Forms.TextBox()
        Me.dtpTargetEndDate = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnAssignTask = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.lblEmpId = New System.Windows.Forms.Label()
        CType(Me.ProjectsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.WorkloadTrackingSystemDBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 98)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Tasks:"
        '
        'cmBxTasks
        '
        Me.cmBxTasks.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmBxTasks.FormattingEnabled = True
        Me.cmBxTasks.Items.AddRange(New Object() {"PLANNING", "ANALYSIS", "DESIGN", "IMPLEMENTATION", "TESTING & INTEGRATION", "MAINTENANCE"})
        Me.cmBxTasks.Location = New System.Drawing.Point(156, 98)
        Me.cmBxTasks.Name = "cmBxTasks"
        Me.cmBxTasks.Size = New System.Drawing.Size(204, 21)
        Me.cmBxTasks.TabIndex = 1
        '
        'btnEnterHours
        '
        Me.btnEnterHours.Location = New System.Drawing.Point(339, 286)
        Me.btnEnterHours.Name = "btnEnterHours"
        Me.btnEnterHours.Size = New System.Drawing.Size(99, 35)
        Me.btnEnterHours.TabIndex = 6
        Me.btnEnterHours.Text = "&Enter Hours"
        Me.btnEnterHours.UseVisualStyleBackColor = True
        '
        'btnProjectInfo
        '
        Me.btnProjectInfo.Location = New System.Drawing.Point(12, 286)
        Me.btnProjectInfo.Name = "btnProjectInfo"
        Me.btnProjectInfo.Size = New System.Drawing.Size(99, 35)
        Me.btnProjectInfo.TabIndex = 7
        Me.btnProjectInfo.Text = "Project &Info"
        Me.btnProjectInfo.UseVisualStyleBackColor = True
        '
        'cmBxProjects
        '
        Me.cmBxProjects.DataSource = Me.ProjectsBindingSource
        Me.cmBxProjects.DisplayMember = "Name"
        Me.cmBxProjects.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmBxProjects.FormattingEnabled = True
        Me.cmBxProjects.Location = New System.Drawing.Point(156, 63)
        Me.cmBxProjects.Name = "cmBxProjects"
        Me.cmBxProjects.Size = New System.Drawing.Size(204, 21)
        Me.cmBxProjects.TabIndex = 0
        Me.cmBxProjects.ValueMember = "ProjectID"
        '
        'ProjectsBindingSource
        '
        Me.ProjectsBindingSource.DataMember = "Projects"
        Me.ProjectsBindingSource.DataSource = Me.WorkloadTrackingSystemDBDataSet
        '
        'WorkloadTrackingSystemDBDataSet
        '
        Me.WorkloadTrackingSystemDBDataSet.DataSetName = "WorkloadTrackingSystemDBDataSet"
        Me.WorkloadTrackingSystemDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(41, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Projects:"
        '
        'ProjectsTableAdapter
        '
        Me.ProjectsTableAdapter.ClearBeforeFill = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(41, 137)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(93, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Task target hours:"
        '
        'txtTargetHrs
        '
        Me.txtTargetHrs.Location = New System.Drawing.Point(156, 137)
        Me.txtTargetHrs.Name = "txtTargetHrs"
        Me.txtTargetHrs.Size = New System.Drawing.Size(100, 20)
        Me.txtTargetHrs.TabIndex = 2
        '
        'dtpTargetEndDate
        '
        Me.dtpTargetEndDate.CustomFormat = "MMM-dd-yyyy"
        Me.dtpTargetEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTargetEndDate.Location = New System.Drawing.Point(156, 173)
        Me.dtpTargetEndDate.Name = "dtpTargetEndDate"
        Me.dtpTargetEndDate.Size = New System.Drawing.Size(204, 20)
        Me.dtpTargetEndDate.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(41, 176)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(109, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Task target end date:"
        '
        'btnAssignTask
        '
        Me.btnAssignTask.Location = New System.Drawing.Point(261, 222)
        Me.btnAssignTask.Name = "btnAssignTask"
        Me.btnAssignTask.Size = New System.Drawing.Size(99, 35)
        Me.btnAssignTask.TabIndex = 4
        Me.btnAssignTask.Text = "&Assign Task"
        Me.btnAssignTask.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(156, 222)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(99, 35)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'lblEmpId
        '
        Me.lblEmpId.AutoSize = True
        Me.lblEmpId.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmpId.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblEmpId.Location = New System.Drawing.Point(12, 9)
        Me.lblEmpId.Name = "lblEmpId"
        Me.lblEmpId.Size = New System.Drawing.Size(106, 16)
        Me.lblEmpId.TabIndex = 9
        Me.lblEmpId.Text = "Employee ID:"
        '
        'frmSelectProject
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(450, 351)
        Me.Controls.Add(Me.lblEmpId)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnAssignTask)
        Me.Controls.Add(Me.dtpTargetEndDate)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtTargetHrs)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cmBxProjects)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnProjectInfo)
        Me.Controls.Add(Me.btnEnterHours)
        Me.Controls.Add(Me.cmBxTasks)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmSelectProject"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Select Project"
        CType(Me.ProjectsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.WorkloadTrackingSystemDBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents cmBxTasks As ComboBox
    Friend WithEvents btnEnterHours As Button
    Friend WithEvents btnProjectInfo As Button
    Friend WithEvents cmBxProjects As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents WorkloadTrackingSystemDBDataSet As WorkloadTrackingSystemDBDataSet
    Friend WithEvents ProjectsBindingSource As BindingSource
    Friend WithEvents ProjectsTableAdapter As WorkloadTrackingSystemDBDataSetTableAdapters.ProjectsTableAdapter
    Friend WithEvents Label3 As Label
    Friend WithEvents txtTargetHrs As TextBox
    Friend WithEvents dtpTargetEndDate As DateTimePicker
    Friend WithEvents Label4 As Label
    Friend WithEvents btnAssignTask As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents lblEmpId As Label
End Class
