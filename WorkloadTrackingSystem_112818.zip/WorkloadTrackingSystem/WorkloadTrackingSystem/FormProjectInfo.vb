﻿Public Class frmProjectInfo
    Private Sub frmProjectInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'get login employee id
        Dim loginFrm As frmLogin = Me.Owner
        lblEmpId.Text = "Employee ID: " & loginFrm.DeveloperId.ToString

        Dim adapter = New WorkloadTrackingSystemDBDataSetTableAdapters.ProjectInfoTableAdapter
        dgvProjectInfo.DataSource = adapter.GetData(loginFrm.DeveloperId)
    End Sub

    Private Sub dgvProjectInfo_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvProjectInfo.CellContentClick

    End Sub
End Class