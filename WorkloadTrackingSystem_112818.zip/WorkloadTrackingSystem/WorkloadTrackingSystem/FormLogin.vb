﻿Public Class frmLogin
    Private mdeveloperId As Integer
    Public Property DeveloperId() As Integer
        Get
            Return mdeveloperId
        End Get
        Set(ByVal value As Integer)
            mdeveloperId = value
        End Set
    End Property
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Application.Exit()  'close application
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If String.IsNullOrEmpty(txtUsername.Text) Then
            MessageBox.Show("Please enter username.")
            Return
        End If
        If String.IsNullOrEmpty(txtPassword.Text) Then
            MessageBox.Show("Please enter password.")
            Return
        End If

        Try
            Dim adapter As New WorkloadTrackingSystemDBDataSetTableAdapters.EmployeesTableAdapter
            Dim empTable As WorkloadTrackingSystemDBDataSet.EmployeesDataTable = adapter.GetLoginEmp(txtUsername.Text, txtPassword.Text)

            If empTable Is Nothing Or empTable.Rows.Count <= 0 Then
                MessageBox.Show("Invalid username or password!")
                txtPassword.Clear()
                txtUsername.Clear()
                txtUsername.Focus()
            Else
                Dim objEmp As WorkloadTrackingSystemDBDataSet.EmployeesRow = empTable.Rows(0)
                If objEmp.IsManager Then
                    Dim objFrmManagerPnl As New frmManagerPanel
                    objFrmManagerPnl.ShowDialog()
                Else
                    Dim objFrmSelectProj As New frmSelectProject
                    DeveloperId = objEmp.EmployeeID
                    objFrmSelectProj.ShowDialog(Me)
                End If
                txtPassword.Clear()
                txtUsername.Clear()
                txtUsername.Focus()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub lnkLblSignUp_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lnkLblSignUp.LinkClicked
        Dim objFrmAddEmp As New frmAddEmployee
        objFrmAddEmp.ShowDialog()
    End Sub
End Class
